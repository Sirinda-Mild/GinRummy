/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package code;

import java.util.ArrayList;
import javafx.collections.ObservableList;
import javafx.scene.Node;

public class DrawPile extends UpCard {

    public DrawPile(ObservableList<Node> cards) {
        super(cards);
    }

}
